# Coding-Raja-Technologies-Internship1
 Open index.html file to create resume.
